<?php
class Menu_db extends CI_Model {

	function __construct() {
		parent::__construct();
		//  $this->load->helper('url');
		$this->load->database();
		$this->load->library('session');
	}


	function check_user_info($uname , $password)
	{

		if($uname != ""  and $password != "" )
		{
			$res = $this->db->query("SELECT username,user_type,hash,name FROM `system_users` where username = '".$uname."' and password='".$password."' ;");
			return $res->row_array();
		}
		else
		{
			return 0;
		}

	}
	
	
	function check_user_by_hash($hash="")
	{

		if($hash != "")
		{
			$res = $this->db->query("SELECT username,user_type,hash,name FROM `system_users` where hash = '".$hash."';");
			return $res->row_array();
		}
		else
		{
			return 0;
		}

	}
	
// 	function get_privilage($hash="")
// 	{
// 	    if($hash!="")
// 	    {
// 	         //$res = $this->db->query("SELECT * FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."'");
           
//               $res = $this->db->query(" SELECT system_privilage_role.id,system_privilage_role.group_hash,user_hash,table_name,select_op,update_op,insert_op,delete_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."'");
          
//              return $res->result();  
// 	    }
// 	}
	
	function check_query_privilage($query,$hash="")
	{
	    
	   
	    
	    if($query!=""&&trim($query) != "")
	    {
	        //echo $query."---\n"; 
	       $role=false; 
	         //die(print_r($privilate));
	     ////get type of query
	      ////end of get type of query
	      $query=trim(preg_replace('/[\t\n\r\s]+/', ' ', $query));
	      $pieces = explode(" ", $query);
	      $first_pice=trim($pieces[0]);
	      if($first_pice=="select"||$first_pice=="SELECT"||$first_pice=="SET"||$first_pice=="set")
	      {
	      $type="select";
	      ///////////////////get table
    	      if($first_pice=="SET"||$first_pice=="set")
    	      {
    	       $query_split = explode("(", $query);
    	       $query_split = explode(")", $query_split[1]);
    	       //die($query_split[0]);
    	       $new_query=$query_split[0];
    	       $res1 = $this->db->query("explain ".$new_query); 
    	       //die(print_r($res->row_array()));
    	       
    	 
    	      }
    	      else
    	      {
    	         $res1 = $this->db->query("explain ".$query); 
    	         //die(print_r($res->row_array()));
    	      }
    	      /////////////////get table
    	      $acc="";
    	      foreach($res1->result() as $p)
    	      {
    	      //   $acc=$acc.$p->table.","; 
    	      $res = $this->db->query(" SELECT select_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."' and table_name='".$p->table."'");
              $role=$res->row_array()["select_op"];
              if($role=="0")
              break;
              //else
              //$role=1;
              
    	      }
    	      //$acc=substr_replace($acc ,"",-1);
	          //die($acc);
	         
	     
	     // print_r($res->row_array());
	      //$role=1;
	      }
	      else
	      if($first_pice=="insert"||$first_pice=="INSERT")
	      {
	      $type="insert";
	      $second_piece=$pieces[2];
	      $second_piece = explode("(", $second_piece);
	      $res = $this->db->query(" SELECT insert_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."' and table_name='".$second_piece[0]."'");
          $role=$res->row_array()["insert_op"];
	      }
	      else
	      if($first_pice=="update"||$first_pice=="UPDATE")
	      {
	      $type="update";
	      $second_piece=$pieces[1];
	      //$second_piece = explode("(", $second_piece);
	      $res = $this->db->query(" SELECT update_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."' and table_name='".$second_piece."'");
          $role=$res->row_array()["update_op"];
       
          
	     // $res = $this->db->query(" SELECT system_privilage_role.id,system_privilage_role.group_hash,user_hash,table_name,select_op,update_op,insert_op,delete_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."'");
         // print($res->row_array());  
	      }
	     
	      else
	      if($first_pice=="delete"||$first_pice=="DELETE")
	      {
	      $type="delete";
	      $second_piece=$pieces[2];
	      //$second_piece = explode("(", $second_piece);
	      $res = $this->db->query(" SELECT delete_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."' and table_name='".$second_piece."'");
          $role=$res->row_array()["delete_op"];
          //echo $type." ".$role."\n";
	      }
	      
	       return $role;   //if put $role true then all query is run successfully
	        
	    }// end of main if condition
	     

	    
        }
        
        
        
     function isJson($string) {
       json_decode($string);
       return json_last_error() === JSON_ERROR_NONE;
    }
     function JSONTOInsertSQL($query){
        $obj=json_decode($query,JSON_UNESCAPED_UNICODE);
        //die(print_r($obj));
        
        foreach ($obj as $row)
        {
            if(is_array($row))
             $column=$row;
            else
             $table=$row;
           
            
            
          //echo "\n";
        }
       //die();
        $keys   = implode('`,`', array_map('addslashes', array_keys($column)));
        $values = implode("','", array_map('addslashes', array_values($column)));
        return "insert into $table($keys) values('$values')";
    }        
        
        
        
	
	
	
	function run_query($query="",$hash="")
	{
	    
	    //$privilate=$this->get_privilage($hash);
	   
	    if($query!="")
	    {
        	      
        	      if (strpos($query, ';') !== false) {
        	         
        	         $pieces = explode(";", $query);
        	         
        	         $k=0;
        	         //die($pieces[0]." ".$pieces[1]);
            	         for($i=0;$i<count($pieces);$i++)
            	         {
            	             
            	            
            	              if($this->isJson($pieces[$i]))  //ceck if coming json
                                $pieces[$i]=$this->JSONTOInsertSQL($pieces[$i]);
                                
                                // die($query);
                                
                                
            	                if($pieces[$i]!=""&&trim($pieces[$i]) != "")
            	                {
                    	                if (strpos($pieces[$i], 'select') !== false&&!strpos($pieces[$i], '=(select') !== false) {
                    	                    //die("11");
                    	                //check here
                    	                    if($this->check_query_privilage($pieces[$i],$hash))   //check for select
                                	        {
                                	        $res_select= $this->db->query($pieces[$i]);
                                			//$res[$k]=array("query".$k=>$res_select->row_array());
                                				$res[$k]=array("query".$k=>$res_select->result());
                                	        }
                                	        else
                                	        {
                                	          $res[$k] = array("query".$k=>"-1");      
                                	        }
                            	        }
                            	        else   //check if insert update delete
                            	        {
                            	            //die("21");
                            	             //check here
                                	        if($this->check_query_privilage($pieces[$i],$hash))
                                	        {
                                	        $this->db->query($pieces[$i]);
                                	        $res[$k] = array("query".$k=>"1");   
                                	        }
                                	        else
                                	        {
                                	         $res[$k] = array("query".$k=>"-1");      
                                	        }
                            	     
                            	        }
                            	        $k++; 
            	                    
            	                }
                    	          
            	         }
            	         return $res;
        	      
        	      }
        	      else
        	      {
        	           //die("1111111111");
        	           if (strpos($query, 'select') !== false) {
        	                             if($this->check_query_privilage($query,$hash))  //check for select
                                	        {   
                                	             //die("1111111111x");
                                	        $res = $this->db->query($query);
                                	        //$res=array("query"=>$res->row_array());
                                	        $res=array("query"=>$res->result());
                                			//return $res->row_array();  
                                	        }
                                	        else
                                	        {
                                	         $res = array("query"=>"-1");     
                                	        }
                                	        
            	        }
            	        else                                                          //check if insert update delete
            	        {
            	                            if($this->check_query_privilage($query,$hash))
                                	        {  
                                	            //die($query);
                                	        $res = $this->db->query($query);
                                	        //$res=array("query"=>$res->row_array());
                                	        // $res=array("query"=>$res->result());
                                	        $res=array("query"=>"1");
                                	        //return 1;
                                	        }
                                	        else
                                	        {
                                	             //die("222222222");
                                	         $res = array("query"=>"-1");     
                                	        }
            	        }
            	        return $res;
        	      }
	      
	      
    	        
	    }
	    else
	    return 0;
	   	
	}
	
	

///////////////////////////////////////////////////////////////
	function dynamic_select($conditions = "",$table_name,$coloumns="*")
	{
		$query = "SELECT   ".$coloumns." FROM   " . $table_name ;
		if($conditions != "")
		{
			$flag = 0 ;
			foreach ($conditions as $key => $value) {

				if($flag == 0)
				{
					$query = $query . " where " . $key ." = " . $value ;
					$flag = 1 ;
				}
				else
				{
					$query = $query . " and " . $key ." = " . $value ;
				}

			}
		}
		$res = $this->db->query($query);
		return $res->result();

	}

	////////////////////////////////////////////////////////////////////////////////////

	function dynamic_insert($columns = "",$table_name,$get_id="0")
	{
	    $hash_name = $table_name."_hash";
	    $columns[$hash_name] = round(microtime(true) * 10000) . rand(0,1000);

		$columns['user_entry'] = $this->session->userdata('user_id') ;

		$query = "INSERT INTO  " . $table_name ." ( " ;
		$query_2 = " ) VALUES ( ";
		$query_3 = "";
		$query_4 = ")";
		if($columns != "")
		{
			$flag = 0 ;
			foreach ($columns as $key => $value) {

				if($flag == 0)
				{
					$query = $query . " `" . $key ."`" ;
					$flag = 1 ;
					$query_3 = $query_3 . " '" . $value . "'";
				}
				else
				{
					$query = $query . " ,`" . $key ."`" ;
					$query_3 = $query_3 . " ," . $value;
				}

			}
			$query = $query . $query_2 . $query_3 . $query_4 ;
			//die($query);
			$res = $this->db->query($query);
			if($get_id==0)
			    return 1;
			else
			    return $this->db->insert_id();
		}

	}
//////////////////////////////////////////////////////////////////////////////////
	function dynamic_update($columns = "",$table_name)
	{


	
		$columns['user_entry'] = $this->session->userdata('user_id') ;

		$query = "UPDATE  " . $table_name ." SET " ;
		$flag = 0 ;
		foreach ($columns as $key => $value) 
		{

			if($flag == 0)
			{
				$query = $query . " `" . $key . "` = '" . $value . "'";

				$flag = 1 ;
			}
			else
			{
				$query = $query . " , `" . $key . "` = '" . $value . "'";

			}

		}
		

		$query = $query . " where " .$table_name. "_hash = " .$columns[$table_name. "_hash"] ;
		//die($query);
		$res = $this->db->query($query);
		
			return 1;
		
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////


}

?>

