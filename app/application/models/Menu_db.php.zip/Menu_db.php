<?php
class Menu_db extends CI_Model {

	function __construct() {
		parent::__construct();
		//  $this->load->helper('url');
		$this->load->database();
		$this->load->library('session');
	}


	function check_user_info($uname , $password)
	{

		if($uname != ""  and $password != "" )
		{
			$res = $this->db->query("SELECT username,user_type,hash,name FROM `system_users` where username = '".$uname."' and password='".$password."' ;");
			return $res->row_array();
		}
		else
		{
			return 0;
		}

	}
	
	
	function check_user_by_hash($hash="")
	{

		if($hash != "")
		{
			$res = $this->db->query("SELECT username,user_type,hash,name FROM `system_users` where hash = '".$hash."';");
			return $res->row_array();
		}
		else
		{
			return 0;
		}

	}
	
	function get_privilage($hash="")
	{
	    if($hash!="")
	    {
	         //$res = $this->db->query("SELECT * FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."'");
           
              $res = $this->db->query(" SELECT system_privilage_role.id,system_privilage_role.group_hash,user_hash,table_name,select_op,update_op,insert_op,delete_op FROM `system_put_role_to_users` inner join system_privilage_role on system_put_role_to_users.group_hash=system_privilage_role.group_hash where system_put_role_to_users.user_hash='".$hash."'");
          
             return $res->result();  
	    }
	}
	
	function check_query_privilage($query,$privilate="")
	{
	      //die(print_r($privilate));
	     ////get type of query
	      ////end of get type of query
	      $pieces = explode(" ", $query);
	      $first_pice=trim($pieces[0]);
	      if($first_pice=="select"||$first_pice=="SELECT"||$first_pice=="SET"||$first_pice=="set")
	      $type="select";
	      else
	      if($first_pice=="insert"||$first_pice=="INSERT")
	      $type="insert";
	      else
	      if($first_pice=="update"||$first_pice=="UPDATE")
	      $type="update";
	      else
	      if($first_pice=="delete"||$first_pice=="DELETE")
	      $type="delete";
	      
	     
	    //echo $first_pice;
	    
	     
	    
	     
// 	     foreach($privilate as $p)
// 			{
// 			    if($type=="select")
// 			    {
// 			      $role_value=$p->select_op;
// 			    }
// 			    else
// 			    if($type=="insert")
// 			    {
// 			       $role_value=$p->insert_op;  
// 			    }
// 			    else
// 			    if($type=="delete")
// 			    {
// 			      $role_value=$p->select_op;
// 			    }
// 			    else
// 			    if($type=="select")
// 			    {
// 			      $role_value=$p->select_op;
// 			    }
			     
// 			     if (strpos($query, $p->table_name) !== false&&$role_value==1) 
// 			       {
// 			           $flage=1;
// 			          // break;  //if found one ture break beacuse we have one query
// 			       }
// 			        print($p->table_name." ".$role_value."  ".$flage."\n");  
// 			 }
	     return true;
        }
	
	
	
	function run_query($query="",$hash="")
	{
	    
	    $privilate=$this->get_privilage($hash);
	   
	    if($query!="")
	    {
        	      
        	      if (strpos($query, ';') !== false) {
        	         
        	         $pieces = explode(";", $query);
        	         
        	         $k=0;
        	         //die($pieces[0]." ".$pieces[1]);
            	         for($i=0;$i<count($pieces);$i++)
            	         {
            	                if($pieces[$i]!="")
            	                {
                    	                if (strpos($pieces[$i], 'select') !== false&&!strpos($pieces[$i], '=(select') !== false) {
                    	                    //die("11");
                    	                //check here
                    	                    if($this->check_query_privilage($pieces[$i],$privilate))
                                	        {
                                	        $res_select= $this->db->query($pieces[$i]);
                                			$res[$k]=array("query".$k=>$res_select->row_array());
                                	        }
                                	        else
                                	        {
                                	          $res[$k] = array("query".$k=>"this user is not have privilage to execute this query");      
                                	        }
                            	        }
                            	        else
                            	        {
                            	            //die("21");
                            	             //check here
                                	        if($this->check_query_privilage($pieces[$i],$privilate))
                                	        {
                                	        $this->db->query($pieces[$i]);
                                	        $res[$k] = array("query".$k=>"1");   
                                	        }
                                	        else
                                	        {
                                	         $res[$k] = array("query".$k=>"this user is not have privilage to execute this query");      
                                	        }
                            	     
                            	        }
                            	        $k++; 
            	                    
            	                }
                    	          
            	         }
            	         return $res;
        	      
        	      }
        	      else
        	      {
        	           if (strpos($query, 'select') !== false) {
        	                             if($this->check_query_privilage($query,$privilate))
                                	        {   
                                	        $res = $this->db->query($query);
                                			return $res->row_array();  
                                	        }
                                	        else
                                	        {
                                	         $res[$k] = array("query".$k=>"this user is not have privilage to execute this query");     
                                	        }
                                	        
            	        }
            	        else
            	        {
            	                            if($this->check_query_privilage($query,$privilate))
                                	        {  
                                	        $res = $this->db->query($query);
                                	        return 1;
                                	        }
                                	        else
                                	        {
                                	         $res[$k] = array("query".$k=>"this user is not have privilage to execute this query");     
                                	        }
            	        }
        	      }
	      
	      
    	        
	    }
	    else
	    return 0;
	   	
	}
	
	

///////////////////////////////////////////////////////////////
	function dynamic_select($conditions = "",$table_name,$coloumns="*")
	{
		$query = "SELECT   ".$coloumns." FROM   " . $table_name ;
		if($conditions != "")
		{
			$flag = 0 ;
			foreach ($conditions as $key => $value) {

				if($flag == 0)
				{
					$query = $query . " where " . $key ." = " . $value ;
					$flag = 1 ;
				}
				else
				{
					$query = $query . " and " . $key ." = " . $value ;
				}

			}
		}
		$res = $this->db->query($query);
		return $res->result();

	}

	////////////////////////////////////////////////////////////////////////////////////

	function dynamic_insert($columns = "",$table_name,$get_id="0")
	{
	    $hash_name = $table_name."_hash";
	    $columns[$hash_name] = round(microtime(true) * 10000) . rand(0,1000);

		$columns['user_entry'] = $this->session->userdata('user_id') ;

		$query = "INSERT INTO  " . $table_name ." ( " ;
		$query_2 = " ) VALUES ( ";
		$query_3 = "";
		$query_4 = ")";
		if($columns != "")
		{
			$flag = 0 ;
			foreach ($columns as $key => $value) {

				if($flag == 0)
				{
					$query = $query . " `" . $key ."`" ;
					$flag = 1 ;
					$query_3 = $query_3 . " '" . $value . "'";
				}
				else
				{
					$query = $query . " ,`" . $key ."`" ;
					$query_3 = $query_3 . " ," . $value;
				}

			}
			$query = $query . $query_2 . $query_3 . $query_4 ;
			//die($query);
			$res = $this->db->query($query);
			if($get_id==0)
			    return 1;
			else
			    return $this->db->insert_id();
		}

	}
//////////////////////////////////////////////////////////////////////////////////
	function dynamic_update($columns = "",$table_name)
	{


	
		$columns['user_entry'] = $this->session->userdata('user_id') ;

		$query = "UPDATE  " . $table_name ." SET " ;
		$flag = 0 ;
		foreach ($columns as $key => $value) 
		{

			if($flag == 0)
			{
				$query = $query . " `" . $key . "` = '" . $value . "'";

				$flag = 1 ;
			}
			else
			{
				$query = $query . " , `" . $key . "` = '" . $value . "'";

			}

		}
		

		$query = $query . " where " .$table_name. "_hash = " .$columns[$table_name. "_hash"] ;
		//die($query);
		$res = $this->db->query($query);
		
			return 1;
		
	}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////


}

?>

